import React from 'react'
import './Navbar1.scss'

export default function Navbar1() {
    return (
        <div>
            <div className="main__navigation">
                <div className="header container">
                    <div className="row">
                        <div>
                            <a
                                href="/login"
                            >
                                <i className="fa-regular fa-user"></i>
                                <span className="user-message">Login</span>
                            </a>
                        </div>
                        <div className='home'>
                            <a
                                href="/"
                                aria-label="Home"
                                title="GODIVA Logo"
                            >
                                <h1 className="logo-home">GODIVA</h1>
                                <p className='p'>Belgium 1926</p>
                            </a>
                        </div>
                        <div className="search-bar">


                            <div className="site-search">
                                <form
                                    role="search"
                                    action="/on/demandware.store/Sites-Godiva-Site/en_US/Search-Show"
                                    method="get"
                                    name="simpleSearch"
                                >
                                    <div class="input-group">
                                        <div class="form-outline">
                                            <input id="search-focus" type="search" class="form-control" placeholder="Search (keywords,etc)" />
                                        </div>
                                        <button type="button" class="btn ">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>

                                </form>
                            </div>


                            <div
                                className="minicart"
                                data-action-url="/on/demandware.store/Sites-Godiva-Site/en_US/Cart-MiniCartShow"
                                data-ahref="https://www.godiva.com/cart"
                            >
                                <div className="minicart-total hide-link-md">
                                    <a
                                        className="minicart-link"
                                        href="https://www.godiva.com/cart"
                                        title="Cart 0 Items"
                                        aria-label="Cart 0 Items"
                                        aria-haspopup="true"
                                    >
                                        <i className="fa-solid fa-bag-shopping"></i>
                         
                                        <span className="minicart-quantity ">0</span>
                                    </a>
                                </div>
                                <div className="popover popover-bottom" />
                                <div
                                    className="modal fade"
                                    id="removeProductModal"
                                    tabIndex={-1}
                                    role="dialog"
                                    aria-labelledby="removeProductLineItemModal"
                                >
                                    <div className="modal-dialog" role="document">
                                        <div className="modal-content">
                                            <div className="modal-header delete-confirmation-header">
                                                <h2 className="modal-title" id="removeProductLineItemModal">
                                                    Remove Product?
                                                </h2>
                                                <button
                                                    type="button"
                                                    className="close"
                                                    data-dismiss="modal"
                                                    aria-label="Close"
                                                >
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                            </div>
                                            <div className="modal-body-remove delete-confirmation-body">
                                                Are you sure you want to remove the following product from
                                                the cart?
                                                <p className="product-to-remove" />
                                            </div>
                                            <div className="modal-footer-remove">
                                                <button
                                                    type="button"
                                                    className="btn btn-brown-outline"
                                                    data-dismiss="modal"
                                                >
                                                    Cancel
                                                </button>
                                                <button
                                                    type="button"
                                                    className="btn btn-brown-custom cart-delete-confirmation-btn"
                                                    data-dismiss="modal"
                                                >
                                                    Yes
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div
                    className="main-menu navbar-toggleable-sm menu-toggleable-left multilevel-dropdown d-none d-md-block"
                    id="sg-navbar-collapse"
                >
                    <div className="container top-navigation">
                        <div className="row">
                            <nav
                                className="navbar navbar-expand-md bg-inverse col-12"
                                aria-label="Main"
                            >
                                <div className="close-menu clearfix d-lg-none">
                                    <div className="back pull-left">
                                        <button role="button" aria-label="Back to previous menu">
                                            <span className="caret-left" />
                                            Back
                                        </button>
                                    </div>
                                    <div className="close-button pull-right">
                                        <button role="button" aria-label="Close Menu">
                                            Close
                                            <span aria-hidden="true">
                                                <svg
                                                    data-tile="nav-close-icon"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    preserveAspectRatio="xMidYMid"
                                                    width={15}
                                                    height={15}
                                                    viewBox="0 0 30 29"
                                                >
                                                    <defs>
                                                        <style
                                                            dangerouslySetInnerHTML={{
                                                                __html: ".cls-2 {fill: #ffffff;}"
                                                            }}
                                                        />
                                                    </defs>
                                                    <path
                                                        d="M29.4 27C29.4 27 27.3 29.2 27.3 29.2 27.3 29.2 14.7 16.6 14.7 16.6 14.7 16.6 2.1 29.2 2.1 29.2 2.1 29.2 0 27 0 27 0 27 12.6 14.5 12.6 14.5 12.6 14.5 0.2 2.1 0.2 2.1 0.2 2.1 2.3 0 2.3 0 2.3 0 14.7 12.3 14.7 12.3 14.7 12.3 27 0 27 0 27 0 29.1 2.1 29.1 2.1 29.1 2.1 16.8 14.5 16.8 14.5 16.8 14.5 29.4 27 29.4 27Z"
                                                        className="cls-2"
                                                        fillRule="evenodd"
                                                    />
                                                </svg>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                                <div className="menu-group">
                                    <ul className="nav navbar-nav" role="menu">
                                    
                                        <li className="nav-item" role="presentation">
                                            <a
                                                href="/category/2"
                                                id="best-selling-chocolate-desktop"
                                                className="nav-link"
                                                role="link"
                                                tabIndex={0}
                                            >
                                                Best Sellers
                                            </a>
                                        </li>
                                        <li className="nav-item dropdown" role="presentation">
                                            <a
                                                href="/category/3"
                                                id="best-selling-chocolate-desktop"
                                                className="nav-link"
                                                role="link"
                                                tabIndex={0}
                                            >
                                                Chocolate
                                            </a>
                                        </li>
                                        <li className="nav-item dropdown" role="presentation">
                                            <a
                                                href="/category/4"
                                                id="best-selling-chocolate-desktop"
                                                className="nav-link"
                                                role="link"
                                                tabIndex={0}
                                            >
                                                Gifts
                                            </a>
                                        </li>
                                        <li className="nav-item dropdown" role="presentation">
                                            <a
                                                href="/category/5"
                                                id="best-selling-chocolate-desktop"
                                                className="nav-link"
                                                role="link"
                                                tabIndex={0}
                                            >
                                                Sales &amp; Deals
                                            </a>
                                        </li>
                                        <li className="nav-item dropdown" role="presentation">
                                            <a
                                                href="/category/:5"
                                                id="best-selling-chocolate-desktop"
                                                className="nav-link"
                                                role="link"
                                                tabIndex={0}
                                            >
                                                About GODIVA
                                            </a>
                                        </li>
                                
                                        <li className="nav-item" role="presentation">
                                            <a
                                                href="/godiva-in-the-aisle"
                                                id="godiva-in-the-aisle-desktop"
                                                className="nav-link"
                                                role="link"
                                                tabIndex={0}
                                            >
                                                Grocery Aisle
                                            </a>
                                        </li>

                                    </ul>
                                </div>

                            </nav>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    )
}
